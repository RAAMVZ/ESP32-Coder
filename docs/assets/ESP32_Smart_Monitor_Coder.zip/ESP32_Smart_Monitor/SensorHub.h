#pragma once
#include <Arduino.h>

struct SensorReading {
  uint32_t timestampMs = 0;
  float voltage = 0.0f;
  float filteredVoltage = 0.0f;
};

class SensorHub {
 public:
  void begin(uint8_t pin);
  SensorReading read();
 private:
  uint8_t pin_ = 34;
  float filtered_ = 0.0f;
  bool initialized_ = false;
};
