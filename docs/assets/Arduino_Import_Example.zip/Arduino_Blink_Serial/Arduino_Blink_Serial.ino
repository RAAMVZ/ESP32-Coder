#include <Arduino.h>
#include "BlinkConfig.h"

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("LED on");
  delay(BLINK_DELAY_MS);
  digitalWrite(LED_PIN, LOW);
  delay(BLINK_DELAY_MS);
}
