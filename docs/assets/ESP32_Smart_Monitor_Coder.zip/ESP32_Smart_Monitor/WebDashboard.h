#pragma once
#include <Arduino.h>
#include <WebServer.h>
#include "SensorHub.h"

class WebDashboard {
 public:
  void begin(const char* ssid, const char* password);
  void update(const SensorReading& latest);
  void handleClient();
 private:
  WebServer server_{80};
  SensorReading reading_{};
  void serveStatus();
};
