#include "SensorHub.h"
#include "AppConfig.h"

void SensorHub::begin(uint8_t pin) {
  pin_ = pin;
  analogReadResolution(12);
  analogSetPinAttenuation(pin_, ADC_11db);
}

SensorReading SensorHub::read() {
  const uint16_t raw = analogRead(pin_);
  const float volts = raw * Config::ADC_REFERENCE / 4095.0f;
  if (!initialized_) { filtered_ = volts; initialized_ = true; }
  filtered_ += Config::FILTER_ALPHA * (volts - filtered_);
  return { millis(), volts, filtered_ };
}
