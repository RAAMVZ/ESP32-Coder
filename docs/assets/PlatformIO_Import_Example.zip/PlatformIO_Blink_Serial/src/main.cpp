#include <Arduino.h>
#include "BlinkConfig.h"

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
}
void loop() {
  digitalWrite(LED_PIN, !digitalRead(LED_PIN));
  Serial.println("tick");
  delay(BLINK_DELAY_MS);
}
