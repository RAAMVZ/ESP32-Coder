#pragma once
#include <Arduino.h>

namespace Pins {
  constexpr uint8_t SENSOR_ADC = 34;
  constexpr uint8_t STATUS_LED = 2;
}

namespace Config {
  constexpr const char* AP_SSID = "SmartMonitor-ESP32";
  constexpr const char* AP_PASSWORD = "monitor2026";
  constexpr uint32_t SAMPLE_INTERVAL_MS = 250;
  constexpr float ADC_REFERENCE = 3.3f;
  constexpr float FILTER_ALPHA = 0.15f;
}
