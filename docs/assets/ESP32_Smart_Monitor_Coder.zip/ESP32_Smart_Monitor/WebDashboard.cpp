#include "WebDashboard.h"
#include <WiFi.h>

void WebDashboard::begin(const char* ssid, const char* password) {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(ssid, password);
  server_.on("/api/status", HTTP_GET, [this]() { serveStatus(); });
  server_.on("/", HTTP_GET, [this]() {
    server_.send(200, "text/html", "<h1>ESP32 Smart Monitor</h1>");
  });
  server_.begin();
}

void WebDashboard::update(const SensorReading& latest) {
  reading_ = latest;
}

void WebDashboard::handleClient() { server_.handleClient(); }

void WebDashboard::serveStatus() {
  String json = "{\"voltage\":" + String(reading_.voltage, 3);
  json += ",\"filtered\":" + String(reading_.filteredVoltage, 3);
  json += ",\"uptime\":" + String(reading_.timestampMs) + "}";
  server_.send(200, "application/json", json);
}
