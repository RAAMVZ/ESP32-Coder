#pragma once
#include <Preferences.h>

class SettingsStore {
 public:
  void begin();
  bool isLoggingEnabled() const;
  void setLoggingEnabled(bool enabled);
 private:
  Preferences preferences_;
  bool loggingEnabled_ = true;
};
