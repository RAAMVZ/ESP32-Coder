#pragma once
constexpr uint8_t LED_PIN = 2;
constexpr unsigned BLINK_DELAY_MS = 500;
