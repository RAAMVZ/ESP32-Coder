#include <Arduino.h>
#include "AppConfig.h"
#include "SensorHub.h"
#include "WebDashboard.h"
#include "SettingsStore.h"

SensorHub sensors;
WebDashboard dashboard;
SettingsStore settings;

uint32_t lastSampleMs = 0;

void setup() {
  Serial.begin(115200);
  delay(200);

  settings.begin();
  sensors.begin(Pins::SENSOR_ADC);
  dashboard.begin(Config::AP_SSID, Config::AP_PASSWORD);

  Serial.println("[SmartMonitor] System ready");
}

void loop() {
  const uint32_t now = millis();

  if (now - lastSampleMs >= Config::SAMPLE_INTERVAL_MS) {
    lastSampleMs = now;
    const SensorReading sample = sensors.read();
    dashboard.update(sample);

    if (settings.isLoggingEnabled()) {
      Serial.printf("ADC: %.2f V | Avg: %.2f V\n",
                    sample.voltage, sample.filteredVoltage);
    }
  }

  dashboard.handleClient();
  delay(2);
}
