ESP32 Smart Monitor — native ESP32 Coder project / родной проект ESP32 Coder

RU: Распакуйте ESP32_Smart_Monitor в C:\ESP32-Coder\Projects\.
Откройте «Открыть» → «Открыть проект» и выберите папку ESP32_Smart_Monitor.
Все 8 файлов .cpp/.h располагаются в КОРНЕ папки проекта — без src/ и include/.
esp32coder.ini содержит конфигурацию проекта. libs/ — папка его библиотек.
runtime/ в папке приложения используется для установленных компонентов.
build_temp/ может появиться после сборки (иногда в другом расположении).
Плата: ESP32 Dev Module. ADC GPIO34. Установите SDK и toolchain через «Компоненты».
Пример демонстрационный, проверка компиляции и на реальном оборудовании не проводилась.

EN: Extract ESP32_Smart_Monitor into C:\ESP32-Coder\Projects\.
Choose Open → Open project and select the ESP32_Smart_Monitor folder.
All 8 .cpp/.h files live directly in the PROJECT ROOT, with no src/ or include/.
esp32coder.ini stores project config; libs/ stores project-local libraries.
The app uses runtime/ for components; build_temp/ may appear after a build (or elsewhere).
Board: ESP32 Dev Module. ADC GPIO34. Install SDK and toolchain via Components.
Demo only; compilation and hardware have not been tested.


MONITOR / МОНИТОР ПОРТА:
[SmartMonitor] System ready
ADC: 1.50 V | Avg: 1.50 V
ADC: 1.55 V | Avg: 1.51 V
ADC: 1.60 V | Avg: 1.52 V
ADC: 1.68 V | Avg: 1.54 V
Sample numeric ADC values; real hardware values will vary. / Показания ADC условные; на реальной плате будут отличаться.
