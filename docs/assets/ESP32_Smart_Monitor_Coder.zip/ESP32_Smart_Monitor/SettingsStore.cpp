#include "SettingsStore.h"

void SettingsStore::begin() {
  preferences_.begin("smartmonitor", false);
  loggingEnabled_ = preferences_.getBool("logging", true);
}

bool SettingsStore::isLoggingEnabled() const {
  return loggingEnabled_;
}

void SettingsStore::setLoggingEnabled(bool enabled) {
  loggingEnabled_ = enabled;
  preferences_.putBool("logging", enabled);
}
